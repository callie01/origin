﻿using LibrarySystem.Areas.Managers.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;

namespace LibrarySystem.Controllers
{
    public class HomeController : Controller
    {
        private MyDb1 db = new MyDb1();

        //首页，图书检索
        public ActionResult Index(string search)
        {
           
            ViewBag.search = search;
            var t = db.BooksTables.ToList();

            //查询到的字符串不为空
            if (string.IsNullOrEmpty(search)==false)
            {
                t = t.Where(m=>m.BookName.Contains(search)).ToList();
            }
            return View(t);
        }

        //图书借阅
        public ActionResult Borrow([Bind(Include = "BookId,BookName,UserId,UaerName,UserIphone,BorrowDate,ReturnDate,BorrowStatus")] BorrowTable borrowTable,string bookname)
        {
            //int bookids = bookid;
            //string booknames = bookname;
            string userid = (string)Session["viewId"];
            //string time = DateTime.Now.ToString("yyyyMMdd HH:mm:ss");
            //string reTime= DateTime.Parse(DateTime.Now.ToString("yyyy-MM-01")).AddMonths(1).ToShortDateString();
            borrowTable.BookId ="123";
            borrowTable.BookName = bookname;
            borrowTable.UserId = "123456";
            borrowTable.UaerName = "2222222";
            borrowTable.UserIphone = "1234567896";
            borrowTable.BorrowDate = DateTime.Now;
            borrowTable.ReturnDate = DateTime.Now.AddMonths(1);
            borrowTable.BorrowStatus = "未归还";
            db.BorrowTables.Add(borrowTable);
            db.SaveChanges();
        
            //SqlConnection conn = new SqlConnection("data source=(LocalDb)\\MSSQLLocalDB;initial catalog=LibrarySystem.Areas.Managers.Models.MyDb1;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework");
            //string str = "insert into BooksTable(BorrowId,BookId,BookName,UserId,UaerName,UserIphone,BorrowDate,ReturnDate,BorrowStatus) values('','" + bookid + "','"+ bookname + "','"+ userid + "','callie','12345678902','"+time+"','"+ reTime + "','未归还')";
            //SqlCommand cmd = new SqlCommand(str, conn);
            //conn.Open();
            //cmd.ExecuteNonQuery();
            //conn.Close();
            return Content("");
        }

        //我的主页
        public ActionResult Home(string viewId)
        {
            string user = viewId;
            var c = db.BorrowTables.ToList();

            if (user != null)
            {
                if (string.IsNullOrEmpty(user) == false)
                {
                    c = c.Where(m => m.UserId.Contains(user)).ToList();
                }
                else
                {
                    return Content(ViewBag.message2 = "暂无借阅书籍信息");
                }
            }
            else
            {
                return Content("<script>alert('请先登录账号！');self.location.href='Login/';</script>");
            }

            return View(c);

        }

        //登录
        public ActionResult Login(UsersTable user,string role)
        {
           
           // string role1 = Request.Form["role"].ToString();
            if (!ModelState.IsValid)
            {
                //普通用户登录
                
                if (role == "1")
                {
                    if (IsValidUser(user))
                    {
                        //清除Session存值
                        //HttpContext.Session.Remove("user_id");
                        //HttpContext.Session.Remove("user_pwd");
                        HttpContext.Session.Remove("viewId");
                        Session["viewId"] = user.UserId;
                        return RedirectToAction("Home", "Home", new { area = "", viewId=user.UserId});
                    }
                    else
                    {
                        ModelState.AddModelError("ErrorMessage", "登录失败，用户名或密码错误！");
                        return View("Login");
                    }
                }
                //管理员登录
                if (role == "2")
                {
                    if (IsValidManager(user))
                    {
                        HttpContext.Session.Remove("viewName");
                        Session["viewName2"] = user.UserId;
                        return RedirectToAction("Index", "Pages", new { area = "Managers"});
                    }
                    else
                    {
                        ModelState.AddModelError("ErrorMessage", "登录失败，用户名或密码错误！");
                        return View("Login");
                    }
                }
            }

        
            return View();
        }


        //工具类1，用于验证普通用户账号密码
        private bool IsValidUser(UsersTable user)
        {
            var user1 = db.UsersTable.Where(m => m.UserId == user.UserId && m.UserPassword == user.UserPassword).SingleOrDefault();
            if (user1 != null)
            {
                ViewBag.viewID = user1.UserId;
                return true;
            }
            else
            {
                return false;
            }
        }

        //工具类2，用于验证管理员账号密码

        private bool IsValidManager(UsersTable user2)
        {
            var user1 = db.ManagersTables.Where(m => m.MgId == user2.UserId && m.MgPassword == user2.UserPassword).SingleOrDefault();
            if (user1 != null)
            {
               
                //ViewBag.viewName = user1.MgName;
                return true;
            }
            else
            {
                return false;
            }
        }


        //注册用户
        public ActionResult register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult register([Bind(Include = "UserId,UserName,UserPassword")] UsersTable UsersTables)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    db.UsersTable.Add(UsersTables);
                    db.SaveChanges();

                    return Content("<script >alert('注册成功！');self.location.href='register/';</script >");

                }
            }
            catch
            {
                return Content("<script>alert('注册失败：该账号已存在！');self.location.href='register/';</script>");
            }
            return View();
        }


      


   



    }
}