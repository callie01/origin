﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using LibrarySystem.Areas.Managers.Models;

namespace LibrarySystem.Areas.Managers.Controllers
{
    public class BooksTablesController : Controller
    {
        private MyDb1 db = new MyDb1();

        // GET: Managers/BooksTables
        public ActionResult Index()
        {
            return View(db.BooksTables.ToList());
        }

        // GET: Managers/BooksTables/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BooksTable booksTable = db.BooksTables.Find(id);
            if (booksTable == null)
            {
                return HttpNotFound();
            }
            return View(booksTable);
        }

        // GET: Managers/BooksTables/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Managers/BooksTables/Create
        // 为了防止“过多发布”攻击，请启用要绑定到的特定属性，有关 
        // 详细信息，请参阅 http://go.microsoft.com/fwlink/?LinkId=317598。
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "BookId,BookName,Category,Author,chubanshe,Stock,BookImage,BookContent,BooksStatus,CreatedTime")] BooksTable booksTable)
        {
            if (ModelState.IsValid)
            {
                db.BooksTables.Add(booksTable);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(booksTable);
        }

        // GET: Managers/BooksTables/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BooksTable booksTable = db.BooksTables.Find(id);
            if (booksTable == null)
            {
                return HttpNotFound();
            }
            return View(booksTable);
        }

        // POST: Managers/BooksTables/Edit/5
        // 为了防止“过多发布”攻击，请启用要绑定到的特定属性，有关 
        // 详细信息，请参阅 http://go.microsoft.com/fwlink/?LinkId=317598。
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "BookId,BookName,Category,Author,chubanshe,Stock,BookImage,BookContent,BooksStatus,CreatedTime")] BooksTable booksTable)
        {
            if (ModelState.IsValid)
            {
                db.Entry(booksTable).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(booksTable);
        }

        // GET: Managers/BooksTables/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BooksTable booksTable = db.BooksTables.Find(id);
            if (booksTable == null)
            {
                return HttpNotFound();
            }
            return View(booksTable);
        }

        // POST: Managers/BooksTables/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            BooksTable booksTable = db.BooksTables.Find(id);
            db.BooksTables.Remove(booksTable);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }


        //查询图书
        public ActionResult SearchInfo(string search)
        {
            ViewBag.search = search;
            var t = db.BooksTables.Include(m=>m.BookName).ToList();
            if (string.IsNullOrEmpty(search)==false)
            {
                t = t.Where(m => m.BookName.Contains(search)).ToList();
            }
            return PartialView(t);
        }
    }
}
