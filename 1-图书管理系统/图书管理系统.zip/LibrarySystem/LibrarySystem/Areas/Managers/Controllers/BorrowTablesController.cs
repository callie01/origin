﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using LibrarySystem.Areas.Managers.Models;

namespace LibrarySystem.Areas.Managers.Controllers
{
    public class BorrowTablesController : Controller
    {
        private MyDb1 db = new MyDb1();

        // GET: Managers/BorrowTables
        public ActionResult Index()
        {
            return View(db.BorrowTables.ToList());
        }

        // GET: Managers/BorrowTables/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BorrowTable borrowTable = db.BorrowTables.Find(id);
            if (borrowTable == null)
            {
                return HttpNotFound();
            }
            return View(borrowTable);
        }

        // GET: Managers/BorrowTables/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Managers/BorrowTables/Create
        // 为了防止“过多发布”攻击，请启用要绑定到的特定属性，有关 
        // 详细信息，请参阅 http://go.microsoft.com/fwlink/?LinkId=317598。
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "BorrowId,BookId,BookName,UserId,UaerName,UserIphone,BorrowDate,ReturnDate,BorrowStatus")] BorrowTable borrowTable)
        {
            if (ModelState.IsValid)
            {

                db.BorrowTables.Add(borrowTable);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(borrowTable);
        }

        // GET: Managers/BorrowTables/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BorrowTable borrowTable = db.BorrowTables.Find(id);
            if (borrowTable == null)
            {
                return HttpNotFound();
            }
            return View(borrowTable);
        }

        // POST: Managers/BorrowTables/Edit/5
        // 为了防止“过多发布”攻击，请启用要绑定到的特定属性，有关 
        // 详细信息，请参阅 http://go.microsoft.com/fwlink/?LinkId=317598。
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "BorrowId,BookId,BookName,UserId,UaerName,UserIphone,BorrowDate,ReturnDate,BorrowStatus")] BorrowTable borrowTable)
        {
            if (ModelState.IsValid)
            {
                db.Entry(borrowTable).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(borrowTable);
        }

        // GET: Managers/BorrowTables/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BorrowTable borrowTable = db.BorrowTables.Find(id);
            if (borrowTable == null)
            {
                return HttpNotFound();
            }
            return View(borrowTable);
        }

        // POST: Managers/BorrowTables/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            BorrowTable borrowTable = db.BorrowTables.Find(id);
            db.BorrowTables.Remove(borrowTable);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
