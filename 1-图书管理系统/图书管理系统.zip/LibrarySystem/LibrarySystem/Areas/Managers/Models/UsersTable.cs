﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace LibrarySystem.Areas.Managers.Models
{
    [Table("UsersTable")]
    public class UsersTable
    {
        [Key,DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Required]
        [Display(Name = "账号")]

        public int UserId { get; set; }
        [Required]
        [StringLength(10)]
        [Display(Name = "姓名")]
        public string UserName { get; set; }
        [Required]
        [StringLength(32)]
        [Display(Name = "密码")]
        public string UserPassword { get; set; }
        [Display(Name = "电话")]
        [Phone]
        public string UserIphone { get; set; }
        [Display(Name = "邮箱")]
        [EmailAddress]
        public string UserEmail { get; set; }
        [Display(Name = "学校")]
        public string UserSchool { get; set; }
        public virtual ICollection<BorrowTable> BorrowTable { get; set; }
    }
}