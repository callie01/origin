﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace LibrarySystem.Areas.Managers.Models
{
    //设置当模型改变时，如果存在数据库就自动创建，如存在就先删除在创建
    public class MyDb1Init:DropCreateDatabaseIfModelChanges<MyDb1>
    {
        protected override void Seed(MyDb1 context)
        {
            base.Seed(context);
        }
    }
}