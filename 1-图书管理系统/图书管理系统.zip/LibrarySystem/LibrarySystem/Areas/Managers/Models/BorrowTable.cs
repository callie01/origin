﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace LibrarySystem.Areas.Managers.Models
{
    [Table("BorrowTable ")]
    public class BorrowTable
    {
        [Key]
        [Required]
        [Display(Name = "借阅号")]
        public int BorrowId { get; set; }
        [Required]
        [Display(Name = "图书编号")]
        public string BookId { get; set; }
        [Required]
        [Display(Name = "图书名称")]
        public string BookName { get; set; }
        [Required]
        [Display(Name = "借阅人编号")]
        public string UserId { get; set; }
        [Required]
        [Display(Name = "借阅人")]
        public string UaerName { get; set; }

        [Display(Name = "联系方式")]
        public string UserIphone { get; set; }
        [Display(Name = "借阅日期")]
        public DateTime? BorrowDate { get; set; } = DateTime.Now;
        [Display(Name = "归还日期")]
        public DateTime? ReturnDate { get; set; } = DateTime.Now.AddMonths(1);
        [Display(Name = "借阅状态")]
        public string BorrowStatus { get; set; }

        public virtual UsersTable UsersTable { get; set; }
        public virtual ICollection<BooksTable> BooksTable { get; set; }
    }
}