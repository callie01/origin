﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace LibrarySystem.Areas.Managers.Models
{
    [Table("BooksTable")]
    public class BooksTable
    {
        internal object books;

        [Key]
        [Required]
        [Display(Name = "编号")]
        public int BookId { get; set; }
        [Required]
        [Display(Name = "书名")]
        [StringLength(30)]
        public string BookName { get; set; }
        [Display(Name = "类别")]
        public string Category { get; set; }
        [Display(Name = "作者")]
        [StringLength(10)]
        public string Author { get; set; }
        [Display(Name = "出版社")]
        public string chubanshe { get; set; }
        [Display(Name = "库存")]
        public int Stock { get; set; }
        [Display(Name = "封面")]
        public string BookImage { get; set; }
        [Display(Name = "简介")]
        [StringLength(100)]
        public string BookContent { get; set; }

        [Display(Name = "创建时间")]
        public DateTime? CreatedTime { get; set; } = DateTime.Now;
        public virtual BorrowTable BorrowTable { get; set; }
      
    }
}