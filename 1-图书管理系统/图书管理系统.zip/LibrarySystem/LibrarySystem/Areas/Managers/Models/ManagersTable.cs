﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace LibrarySystem.Areas.Managers.Models
{
    [Table("ManagersTable")]
    public class ManagersTable
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Required]
        [Display(Name = "账号")]
        public int MgId { get; set; }
        [Required]
        [StringLength(10)]
        [Display(Name = "姓名")]
        public string MgName { get; set; }
        [Required]
        [StringLength(32)]
        [Display(Name = "密码")]
        public string MgPassword { get; set; }
        [Display(Name = "邮箱")]
        [EmailAddress]
        public string MgEmail { get; set; }
    }
}